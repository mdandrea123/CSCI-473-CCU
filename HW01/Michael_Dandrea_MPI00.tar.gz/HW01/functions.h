int is_power_of_2(int n);
void global_sum(double *result, int rank, int size, double my_value);
void int_to_binary(int n, char *binary_str, int bits);

#define MAX_BINARY_LEN 32  // Maximum length for binary representation
