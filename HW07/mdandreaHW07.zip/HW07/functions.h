#include <stdio.h>
#include <stdlib.h>

void malloc2D(double ***a, int jmax, int imax);
void init_vector(double *vector, int size);
void print_vector(double *vector, int size);
